/**
 * Neuron 21 — js/ws.js
 * WebSocket connection manager.
 * Provides: connect(), send(action, data), on(event, handler)
 */

const WS = (() => {
  const PORT     = 7730;
  const URL      = `ws://127.0.0.1:${PORT}/`;
  let   _ws      = null;
  let   _queue   = [];          // commands queued while disconnected
  let   _handlers= {};          // event -> [fn, ...]
  let   _cmdId   = 0;
  let   _pending = {};          // id -> resolve
  let   _retryMs = 1000;
  let   _retrying = false;

  function _connect() {
    _ws = new WebSocket(URL);

    _ws.onopen = () => {
      _retryMs = 1000;
      document.getElementById("conn-dot")?.classList.add("connected");
      // Flush queue
      while (_queue.length) _ws.send(_queue.shift());
      _emit("connected", {});
    };

    _ws.onclose = () => {
      document.getElementById("conn-dot")?.classList.remove("connected");
      _emit("disconnected", {});
      if (!_retrying) {
        _retrying = true;
        setTimeout(_reconnect, _retryMs);
      }
    };

    _ws.onerror = () => {};   // onclose fires next

    _ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        const event = msg.event || "unknown";
        // Resolve pending promise if this is a reply
        if (event === "reply" && msg.id !== undefined && _pending[msg.id]) {
          _pending[msg.id](msg.data);
          delete _pending[msg.id];
        }
        _emit(event, msg.data || {});
      } catch (err) {
        console.warn("WS parse error", err);
      }
    };
  }

  function _reconnect() {
    _retrying = false;
    _retryMs  = Math.min(_retryMs * 1.5, 8000);
    _connect();
  }

  function _emit(event, data) {
    (_handlers[event] || []).forEach(fn => { try { fn(data); } catch(e){} });
    (_handlers["*"]   || []).forEach(fn => { try { fn(event, data); } catch(e){} });
  }

  /** Register an event handler. Use event="*" for all events. */
  function on(event, fn) {
    (_handlers[event] = _handlers[event] || []).push(fn);
  }

  /** Send a command to the engine. Returns a Promise<result>. */
  function send(action, data = {}) {
    const id  = ++_cmdId;
    const msg = JSON.stringify({ action, id, ...data });
    return new Promise((resolve) => {
      _pending[id] = resolve;
      setTimeout(() => { if (_pending[id]) { delete _pending[id]; resolve(null); } }, 8000);
      if (_ws && _ws.readyState === WebSocket.OPEN) {
        _ws.send(msg);
      } else {
        _queue.push(msg);
      }
    });
  }

  // Auto-start
  _connect();

  return { on, send, connected: () => _ws?.readyState === WebSocket.OPEN };
})();
