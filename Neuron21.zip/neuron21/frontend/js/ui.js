/**
 * Neuron 21 — js/ui.js
 * All UI rendering and event wiring.
 */

// ── Utility ──────────────────────────────────────────────────

const $ = id => document.getElementById(id);

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls)  e.className = cls;
  if (text) e.textContent = text;
  return e;
}

function setBar(id, val, max = 1) {
  const fill = document.querySelector(`#${id} .meter-fill`);
  const label = document.querySelector(`#${id} .meter-val`);
  if (fill)  fill.style.width = `${Math.min(100, val / max * 100).toFixed(1)}%`;
  if (label) label.textContent = val.toFixed(2);
}

function setProgress(pct, label) {
  const fill = document.querySelector("#train-progress .progress-fill");
  const lbl  = $("progress-label");
  if (fill) fill.style.width = `${pct}%`;
  if (lbl)  lbl.textContent  = label || "";
}

function appendOutput(html, cls = "") {
  const area = $("output-area");
  if (!area) return;
  const span = document.createElement("span");
  if (cls) span.className = cls;
  span.innerHTML = html + "\n";
  area.appendChild(span);
  area.scrollTop = area.scrollHeight;
  // Trim to last 200 lines
  while (area.childElementCount > 200) area.removeChild(area.firstChild);
}

function toast(msg, type = "") {
  const wrap = $("toast-wrap");
  if (!wrap) return;
  const t = el("div", `toast ${type}`, msg);
  wrap.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

// ── State ─────────────────────────────────────────────────────

let _state = {
  running: false,
  play_mode: false,
  rp_steps: 0,
  config: {},
  emotions: {},
  instincts: {},
  soul: {},
  relational: {},
  history: [],
};

// ── Rendering ─────────────────────────────────────────────────

function renderEmotions(em) {
  const names = ["happiness","sadness","anger","fear","curiosity","calm"];
  names.forEach(n => {
    const row = $(`em-${n}`);
    if (!row) return;
    const fill  = row.querySelector(".meter-fill");
    const label = row.querySelector(".meter-val");
    const v = em[n] ?? 0;
    if (fill)  fill.style.width = `${(v * 100).toFixed(1)}%`;
    if (label) label.textContent = v.toFixed(2);
  });
}

function renderInstincts(iv) {
  const names = ["hunger","tiredness","boredom","pain"];
  names.forEach(n => {
    const row = $(`in-${n}`);
    if (!row) return;
    const fill  = row.querySelector(".meter-fill");
    const label = row.querySelector(".meter-val");
    const v = iv[n] ?? 0;
    if (fill)  fill.style.width = `${(v * 100).toFixed(1)}%`;
    if (label) label.textContent = v.toFixed(2);
  });
  // Wellbeing
  const wb = iv.wellbeing ?? 1;
  const wbFill = document.querySelector("#wellbeing-bar .meter-fill");
  const wbLbl  = $("wellbeing-val");
  if (wbFill) {
    wbFill.style.width = `${(wb * 100).toFixed(1)}%`;
    wbFill.style.background = wb > 0.6 ? "var(--grn)" : wb > 0.35 ? "var(--yel)" : "var(--red)";
  }
  if (wbLbl) wbLbl.textContent = `${(wb * 100).toFixed(0)}%`;
}

function renderSoul(soul) {
  const expEl = $("soul-exp");   if (expEl) expEl.textContent = soul.experience?.toFixed(2) ?? "—";
  const psEl  = $("soul-style");
  if (psEl) {
    const ps = soul.play_style ?? 0.5;
    psEl.textContent = ps < 0.35 ? "image / artist" : ps > 0.65 ? "text / thinker" : "balanced";
  }
}

function renderRelational(rel) {
  const attFill = document.querySelector("#rel-att .meter-fill");
  const resFill = document.querySelector("#rel-res .meter-fill");
  const descEl  = $("rel-desc");
  if (attFill) attFill.style.width = `${((rel.attachment ?? 0.3) * 100).toFixed(1)}%`;
  if (resFill) resFill.style.width = `${((rel.resentment ?? 0) * 100).toFixed(1)}%`;
  if (descEl)  descEl.textContent  = rel.description ?? "Neutral";
}

function renderFace(b64) {
  const img = $("face-img");
  if (img && b64) {
    img.src = `data:image/png;base64,${b64}`;
    img.classList.add("active");
  }
}

function renderHeatmap(gridData) {
  const canvas = $("heatmap-canvas");
  if (!canvas || !gridData?.length) return;
  const rows = gridData.length;
  const cols = gridData[0].length;
  canvas.width  = cols;
  canvas.height = rows;
  const ctx = canvas.getContext("2d");
  const img = ctx.createImageData(cols, rows);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const v = gridData[r][c];
      // Inferno-ish colormap
      const i = (r * cols + c) * 4;
      img.data[i]   = Math.min(255, v * 200 + 50);   // R
      img.data[i+1] = Math.min(255, v * 80);          // G
      img.data[i+2] = Math.min(255, 150 - v * 130);  // B
      img.data[i+3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}

function renderHistory(hist) {
  const box = $("history-list");
  if (!box) return;
  box.innerHTML = "";
  hist.forEach(h => {
    const row = el("div", "history-item");
    row.innerHTML =
      `<span>${h.timestamp}</span>` +
      `<span>${h.itype}</span>` +
      `<span class="h-mse">${h.mse.toFixed(5)}</span>` +
      `<span class="h-event">${h.event}</span>`;
    box.appendChild(row);
  });
}

function renderConfig(cfg) {
  if (cfg.brain_name) $("brain-name").value = cfg.brain_name;
  if (cfg.soul_name)  $("soul-name").value  = cfg.soul_name;
  const badge = $("config-badge");
  if (badge) badge.textContent =
    `h=${cfg.hidden_size}  lr=${cfg.learning_rate}  tl=${cfg.text_len}  img=${cfg.img_dim}x${cfg.img_dim}`;
}

function applyState(data) {
  _state = { ..._state, ...data };
  if (data.emotions)  renderEmotions(data.emotions);
  if (data.instincts) renderInstincts(data.instincts);
  if (data.soul)      renderSoul(data.soul);
  if (data.relational)renderRelational(data.relational);
  if (data.face_b64)  renderFace(data.face_b64);
  if (data.config)    renderConfig(data.config);
  if (data.history)   renderHistory(data.history);
  updateRunButtons(data.running);
}

function updateRunButtons(running) {
  const runBtn  = $("btn-run");
  const stopBtn = $("btn-stop");
  const rewBtn  = $("btn-reward");
  const punBtn  = $("btn-punish");
  if (runBtn)  runBtn.disabled  = !!running;
  if (stopBtn) stopBtn.disabled = !running;
  if (rewBtn)  rewBtn.disabled  = !!running;
  if (punBtn)  punBtn.disabled  = !!running;
}

// ── Soul log ──────────────────────────────────────────────────

function logSoul(msg) {
  const box = $("soul-log");
  if (!box) return;
  const ts   = new Date().toTimeString().slice(0, 8);
  const line = el("div");
  line.innerHTML = `<span style="color:var(--fg2)">[${ts}]</span> ${escHtml(msg)}`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
  while (box.childElementCount > 40) box.removeChild(box.firstChild);
}

function escHtml(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

// ── WS event handlers ─────────────────────────────────────────

WS.on("init", data => {
  applyState(data);
  appendOutput("[Neuron 21 connected]", "out-event");
});

WS.on("connected",    ()   => toast("Connected", ""));
WS.on("disconnected", ()   => toast("Disconnected — reconnecting...", "error"));

WS.on("tick_emotion", data => {
  if (data.emotions)  renderEmotions(data.emotions);
  if (data.instincts) renderInstincts(data.instincts);
  if (data.relational)renderRelational(data.relational);
});

WS.on("tick_soul", data => {
  const thoughtEl = $("face-thought");
  if (thoughtEl && data.thought) thoughtEl.textContent = data.thought;
  if (data.soul) renderSoul(data.soul);
  if (data.care_action) {
    const careEl = $("care-action-label");
    if (careEl) careEl.textContent = `${data.care_action}: ${data.care_desc ?? ""}`;
  }
});

WS.on("tick_face", data => {
  if (data.face_b64) renderFace(data.face_b64);
});

WS.on("run_started", data => {
  updateRunButtons(true);
  setProgress(0, `0 / ${data.iters}  iter`);
  appendOutput(`--- Run (${data.iters} iter) ---`, "out-event");
});

WS.on("progress", data => {
  setProgress(data.pct, `${data.iter}/${data.total}  MSE: ${data.mse}`);
  if (data.output_text)
    appendOutput(`[${data.iter}] ${escHtml(data.output_text)}  MSE:${data.mse}`, "out-text");
});

WS.on("run_complete", data => {
  updateRunButtons(false);
  setProgress(100, `Done  MSE: ${data.mse}`);
  if (data.output_text)
    appendOutput(`Final: ${escHtml(data.output_text)}  MSE:${data.mse}`, "out-event");
  if (data.face_b64) renderFace(data.face_b64);
  if (data.heatmap)  renderHeatmap(data.heatmap);
});

WS.on("reward_applied", data => {
  appendOutput(`Reward x${data.steps}`, "out-reward");
  if (data.face_b64) renderFace(data.face_b64);
  toast(`Reward applied (x${data.steps})`, "care");
});

WS.on("punish_applied", data => {
  appendOutput(`Punish x${data.steps}`, "out-punish");
  if (data.face_b64) renderFace(data.face_b64);
  toast(`Punish applied (x${data.steps})`, "error");
});

WS.on("care_applied", data => {
  toast(`${data.msg}`, "care");
  if (data.face_b64)  renderFace(data.face_b64);
  if (data.emotions)  renderEmotions(data.emotions);
  if (data.instincts) renderInstincts(data.instincts);
});

WS.on("spontaneous", data => {
  logSoul(`[${data.source}] ${data.thought} — "${data.text ?? ""}"`);
  if (data.face_b64) renderFace(data.face_b64);
  appendOutput(`[Soul/${data.source}] ${data.thought} — "${escHtml(data.text ?? "")}"`, "out-soul");
});

WS.on("play_started", data => {
  $("play-indicator")?.classList.add("active");
  toast("Play mode started", "soul");
  appendOutput(`[Play] ${data.msg}`, "out-play");
});

WS.on("play_ended", () => {
  $("play-indicator")?.classList.remove("active");
});

WS.on("play_tick", data => {
  appendOutput(`[Play] ${data.activity}`, "out-play");
  if (data.face_b64) renderFace(data.face_b64);
  if (data.emotions) renderEmotions(data.emotions);
});

WS.on("networks_reset", () => toast("Networks reset", ""));

WS.on("error", data => {
  appendOutput(`[Error] ${escHtml(data.msg)}`, "out-punish");
  toast(data.msg, "error");
});

WS.on("soul_updated", data => {
  if (data.soul) renderSoul(data.soul);
});

// ── Button / Input handlers ───────────────────────────────────

function getTrainParams() {
  return {
    itype:  "text",
    text:   $("text-input")?.value?.trim() ?? "",
    iters:  parseInt($("iters-input")?.value ?? "10"),
    noise:  parseFloat($("noise-slider")?.value ?? "0.02"),
  };
}

function initControls() {

  $("btn-run")?.addEventListener("click", () => {
    const p = getTrainParams();
    if (!p.text) { toast("Enter text first", "error"); return; }
    WS.send("run", p);
  });

  $("btn-stop")?.addEventListener("click", () => WS.send("stop"));

  $("btn-reward")?.addEventListener("click", () => {
    const s = parseFloat($("rp-strength")?.value ?? "1");
    WS.send("reward", { strength: s });
  });

  $("btn-punish")?.addEventListener("click", () => {
    const s = parseFloat($("rp-strength")?.value ?? "1");
    WS.send("punish", { strength: s });
  });

  $("btn-reward-soul")?.addEventListener("click", () => WS.send("reward_soul"));
  $("btn-punish-soul")?.addEventListener("click", () => WS.send("punish_soul"));

  $("btn-approve-care")?.addEventListener("click",   () => WS.send("approve_care"));
  $("btn-discourage-care")?.addEventListener("click", () => WS.send("discourage_care"));

  $("btn-feed")?.addEventListener("click",   () => WS.send("care_feed"));
  $("btn-sleep")?.addEventListener("click",  () => WS.send("care_sleep"));
  $("btn-play")?.addEventListener("click",   () => WS.send("care_play"));
  $("btn-soothe")?.addEventListener("click", () => WS.send("care_soothe"));

  $("btn-extrapolate")?.addEventListener("click", async () => {
    const steps = parseInt($("chain-steps")?.value ?? "5");
    const r = await WS.send("extrapolate", { steps });
    const box = $("chain-output");
    if (!box || !r?.chain) return;
    box.innerHTML = r.chain.map(s =>
      `<div><span style="color:var(--fg2)">Step ${s.step}:</span> ${escHtml(s.text)}</div>`
    ).join("");
  });

  // Config apply
  $("btn-apply-config")?.addEventListener("click", async () => {
    const r = await WS.send("set_config", {
      hidden_size:   parseInt($("cfg-hidden")?.value  ?? "64"),
      learning_rate: parseFloat($("cfg-lr")?.value    ?? "0.01"),
      text_len:      parseInt($("cfg-textlen")?.value ?? "32"),
      img_dim:       parseInt($("cfg-imgdim")?.value  ?? "16"),
    });
    await WS.send("reset_networks");
    renderConfig(r?.config ?? {});
    toast("Config applied — networks reset", "");
  });

  // Name save
  $("btn-save-names")?.addEventListener("click", () => {
    WS.send("set_name", {
      brain_name: $("brain-name")?.value ?? "",
      soul_name:  $("soul-name")?.value  ?? "",
    });
    toast("Names saved", "");
  });

  // Dict load (path entry)
  $("btn-load-dict")?.addEventListener("click", async () => {
    const path = $("dict-path")?.value?.trim();
    if (!path) { toast("Enter a file path", "error"); return; }
    const r = await WS.send("load_dict", { path });
    if (r?.word_count) {
      toast(`Dictionary loaded: ${r.word_count} words`, "care");
      const lbl = $("dict-label");
      if (lbl) lbl.textContent = `${r.word_count} words`;
    } else {
      toast(r?.error ?? "Load failed", "error");
    }
  });

  // Noise slider label
  const noiseSlider = $("noise-slider");
  const noiseLabel  = $("noise-label");
  noiseSlider?.addEventListener("input", () => {
    if (noiseLabel) noiseLabel.textContent = parseFloat(noiseSlider.value).toFixed(3);
  });

  // R/P strength label
  const rpSlider = $("rp-strength");
  const rpLabel  = $("rp-label");
  rpSlider?.addEventListener("input", () => {
    if (rpLabel) rpLabel.textContent = parseFloat(rpSlider.value).toFixed(1);
  });

  // Enter key in text input triggers Run
  $("text-input")?.addEventListener("keydown", e => {
    if (e.key === "Enter") $("btn-run")?.click();
  });

  // Collapse panels
  document.querySelectorAll(".collapse-header").forEach(hdr => {
    hdr.addEventListener("click", () => {
      hdr.classList.toggle("open");
      const body = hdr.nextElementSibling;
      body?.classList.toggle("open");
    });
  });

  // Open panels by default
  document.querySelectorAll(".collapse-header.open").forEach(hdr => {
    hdr.nextElementSibling?.classList.add("open");
  });

  // Request full state on load
  WS.send("get_state").then(r => { if (r) applyState(r); });
}

// ── Boot ──────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", initControls);
