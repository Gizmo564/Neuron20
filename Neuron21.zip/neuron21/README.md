# Neuron 21

A living neural entity simulator with a Python brain and a browser-based interface.

---

## Architecture

```
Python backend (server/)          Browser frontend (frontend/)
─────────────────────────         ────────────────────────────
core/networks.py    ──────────────── WebSocket ──── js/ws.js
core/state.py       Neural logic                    js/ui.js
core/creature.py    Emotion ticks      HTTP          css/style.css
core/face.py        Soul ticks      (file serve)     index.html
server/engine.py    Command router
server/ws_server.py HTTP + WS server
main.py             Entry point
```

**Why two languages?**
- Python handles all neural math, file I/O, periodic ticks, and image generation.
  numpy's vectorised operations are well-suited here; C++ would only help above hidden≈512.
- JavaScript + HTML/CSS handles the interface: smooth animations, flexible layout,
  proper typography, and hardware-accelerated rendering — things tkinter cannot match.
- The boundary is clean: a WebSocket carries JSON commands one way, JSON+base64 events
  the other. Neither side leaks into the other's domain.
- One fewer dependency: matplotlib is no longer needed. The browser renders everything.

---

## Requirements

| Requirement | Notes |
|---|---|
| Python 3.9+ | Standard installer at python.org |
| numpy 1.21+ | `pip install -r requirements.txt` |
| Pillow 9.0+ | Same |
| A web browser | Chrome, Firefox, Safari, Edge — any modern browser |

No tkinter, no matplotlib, no websockets library needed — the WebSocket server is
implemented using only Python's standard library (http.server + socket).

---

## Installation

### Step 1 — Install Python (3.9 or higher)

https://www.python.org/downloads/

Tick "Add Python to PATH" on Windows.

### Step 2 — Install Python dependencies

Open a terminal in the `neuron21/` directory:

```bash
pip install -r requirements.txt
```

### Step 3 — Run

```bash
python main.py
```

The app prints:

```
Neuron 21  —  http://127.0.0.1:7730
Press Ctrl-C to stop.
```

Your default browser opens automatically. If it does not, open
`http://127.0.0.1:7730` manually.

Press **Ctrl-C** in the terminal to stop the server.

---

## Using the app

### Basic training
1. Type text in the **Text** field.
2. Set **Iters** (how many training steps).
3. Click **Run**. Watch MSE fall in the progress bar and output stream.
4. After a run, **Reward** reinforces the output; **Punish** discourages it.

### Extrapolation
Set **Steps** and click **Extrapolate** to chain the output through the network
repeatedly — each step uses the previous output as input.

### Care
The brain has physiological drives. When hunger/tiredness/pain rise:
- **Feed** — reduces hunger
- **Rest / Sleep** — reduces tiredness and consolidates memory
- **Play** — reduces boredom
- **Soothe** — reduces pain

### Soul
The Soul network runs on the emotional state. It proposes autonomous care actions
(visible in the Soul panel). **Approve** or **Discourage** to shape its behaviour.

### Dictionary
Load a plain-text word list (one word per line, or space-separated).
Once loaded, the brain passively trains on random words when idle, and outputs use
dictionary words instead of raw character codes.

### Config
Change hidden size, learning rate, text length, and image dimension.
"Apply & Reset Networks" rebuilds all networks from scratch (weights are lost).
Export/import via the engine's file commands (see engine.py handle_command).

---

## File formats

All file formats are identical to Neuron 20:

| Extension | Contents |
|---|---|
| `.creature.npz` | Brain + Soul + genetics + relational state |
| `.brain.npz` | Neural network weights only |
| `.soul.npz` | Soul network weights only |
| `.ltm.npz` | Long-term memory (consolidated weights + soul memories) |

---

## Troubleshooting

**Browser does not open / shows "connection refused"**
The server may still be starting. Wait 2 seconds and refresh, or open
`http://127.0.0.1:7730` manually.

**"No module named numpy"**
Run `pip install -r requirements.txt` from the `neuron21/` directory.

**"Address already in use"**
Another process is using port 7730. Stop it, or edit `main.py` to use a different port.

**Blank face image**
The face requires at least one training run to populate hidden activations.
Run the network once and the face will update on the next 10-second tick.

**Cannot load dictionary — file not found**
Enter the full absolute path to the file, e.g. `/Users/name/words.txt` or
`C:\Users\name\words.txt`.
