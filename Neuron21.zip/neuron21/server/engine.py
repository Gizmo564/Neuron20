"""
Neuron 21 — server/engine.py
BrainEngine: owns all neural state, processes commands, emits events.
Runs on the Python side; communicates with the JS frontend via WebSocket.
"""

import os
import sys
import random
import datetime
import threading
import tempfile
import base64
import io
import json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.networks  import SimpleNN, SoulNN
from core.state     import EmotionState, InstinctSystem, RelationalState, GeneticsProfile
from core.creature  import Creature
from core.face      import make_face
from core.io_utils  import (text_to_vec, vec_to_text, image_to_vec,
                             load_dictionary, save_long_term_memory,
                             load_long_term_memory)


class BrainEngine:
    """
    All neural logic lives here.  The WebSocket server calls:
        engine.handle_command(cmd_dict) -> optional reply dict
    and subscribes to pushed events via engine.subscribe(callback).
    """

    # ── Config defaults ───────────────────────────────────────
    cfg_hidden_size   = 64
    cfg_learning_rate = 0.01
    cfg_text_len      = 32
    cfg_img_dim       = 16

    def __init__(self):
        self.creature        = Creature()
        self._subscribers    = []          # websocket send callbacks
        self._running        = False
        self._run_thread     = None
        self._last_x         = None
        self._last_itype     = "text"
        self._last_nn        = None
        self._last_interact  = datetime.datetime.now()
        self._play_mode      = False
        self._rp_steps       = 0
        self._history        = []          # [{timestamp, itype, mse, event}, ...]
        self._lock           = threading.Lock()
        self._training_error = None

        # Start periodic ticks
        self._schedule(2.0,  self._emotion_tick)
        self._schedule(8.0,  self._soul_tick)
        self._schedule(3.0,  self._passive_train_tick)
        self._schedule(10.0, self._face_tick)

    # ── Subscription ──────────────────────────────────────────

    def subscribe(self, send_fn):
        self._subscribers.append(send_fn)

    def unsubscribe(self, send_fn):
        self._subscribers = [f for f in self._subscribers if f is not send_fn]

    def _push(self, event: str, data: dict):
        """Push an event to all connected frontends."""
        msg = json.dumps({"event": event, "data": data})
        dead = []
        for fn in self._subscribers:
            try:
                fn(msg)
            except Exception:
                dead.append(fn)
        for fn in dead:
            self.unsubscribe(fn)

    # ── Command dispatcher ────────────────────────────────────

    def handle_command(self, cmd: dict) -> dict:
        action = cmd.get("action", "")
        try:
            handlers = {
                "run":            self._cmd_run,
                "stop":           self._cmd_stop,
                "reward":         self._cmd_reward,
                "punish":         self._cmd_punish,
                "reward_soul":    self._cmd_reward_soul,
                "punish_soul":    self._cmd_punish_soul,
                "care_feed":      lambda _: self._care("feed"),
                "care_sleep":     lambda _: self._care("sleep"),
                "care_play":      lambda _: self._care("play"),
                "care_soothe":    lambda _: self._care("soothe"),
                "approve_care":   lambda _: self._approve_care(),
                "discourage_care":lambda _: self._discourage_care(),
                "extrapolate":    self._cmd_extrapolate,
                "set_config":     self._cmd_set_config,
                "reset_networks": lambda _: self._reset_networks(),
                "get_state":      lambda _: self._full_state(),
                "get_face":       lambda _: {"face_b64": self._render_face_b64(192)},
                "set_name":       self._cmd_set_name,
                "load_dict":      self._cmd_load_dict,
            }
            if action in handlers:
                result = handlers[action](cmd)
                return result or {"ok": True}
            return {"error": f"Unknown action: {action}"}
        except Exception as e:
            import traceback
            return {"error": str(e), "trace": traceback.format_exc()}

    # ── Training ──────────────────────────────────────────────

    def _cmd_run(self, cmd):
        if self._running:
            return {"error": "Already running"}
        itype  = cmd.get("itype", "text")
        text   = cmd.get("text", "")
        iters  = max(1, int(cmd.get("iters", 10)))
        noise  = float(cmd.get("noise", 0.02))

        if itype == "text":
            if not text:
                return {"error": "No text provided"}
            x  = text_to_vec(text, self.cfg_text_len)
            nn = self._ensure_nn("text", self.cfg_text_len, self.cfg_text_len)
        else:
            return {"error": "Image training via file path — use run_image command"}

        self._last_x = x; self._last_itype = itype; self._last_nn = nn
        self._rp_steps = 0
        self._last_interact = datetime.datetime.now()
        if self._play_mode:
            self._exit_play()
        self._running = True
        self._push("run_started", {"iters": iters})

        def _worker():
            for i in range(iters):
                if not self._running:
                    break
                try:
                    lr    = self._eff_lr()
                    eff_n = noise + self.creature.emotions.noise_add() + self.creature.instincts.noise_add()
                    nn.forward(x, noise=eff_n)
                    mse = nn.train(x, lr=lr)
                    self.creature.instincts.on_train(mse)
                    self.creature.emotions.on_mse(mse)
                    pct = int((i + 1) / iters * 100)
                    if i % max(1, iters // 20) == 0 or i == iters - 1:
                        out_text = self._decode_output(nn.forward(x))
                        self._push("progress", {
                            "pct": pct, "iter": i + 1, "total": iters,
                            "mse": round(mse, 6), "output_text": out_text
                        })
                except Exception as e:
                    self._push("error", {"msg": str(e)}); break
            self._running = False
            final_out = nn.forward(x)
            final_mse = float(np.mean((final_out - x) ** 2))
            self._record_history(itype, final_mse, "Run")
            self._push("run_complete", {
                "mse": round(final_mse, 6),
                "output_text": self._decode_output(final_out),
                "heatmap": self._hidden_heatmap(nn),
                "face_b64": self._render_face_b64(96),
            })

        self._run_thread = threading.Thread(target=_worker, daemon=True)
        self._run_thread.start()
        return {"ok": True}

    def _cmd_stop(self, _):
        self._running = False
        return {"ok": True}

    def _cmd_reward(self, cmd):
        if self._last_x is None:
            return {"error": "No training run yet"}
        strength = float(cmd.get("strength", 1.0))
        nn = self._last_nn or self.creature.nn_store.get(self._last_itype)
        if nn:
            for _ in range(10):
                nn.forward(self._last_x)
                nn.train(self._last_x, lr=0.015 * strength)
        self.creature.emotions.on_reward()
        self.creature.relational.on_reward()
        self.creature.soul.reward(self.creature.emotions.to_vec(), s=0.1)
        self._rp_steps += 10
        self._push("reward_applied", {"steps": self._rp_steps,
                                       "face_b64": self._render_face_b64(96)})
        return {"ok": True}

    def _cmd_punish(self, cmd):
        if self._last_x is None:
            return {"error": "No training run yet"}
        strength = float(cmd.get("strength", 1.0))
        nn = self._last_nn or self.creature.nn_store.get(self._last_itype)
        if nn:
            for _ in range(10):
                nx = self._last_x + np.random.randn(*self._last_x.shape) * 0.05
                nn.forward(nx); nn.train(nx, lr=0.007 * strength)
        self.creature.emotions.on_punish()
        self.creature.relational.on_punish()
        self.creature.soul.punish(self.creature.emotions.to_vec(), s=0.08)
        self._rp_steps += 10
        self._push("punish_applied", {"steps": self._rp_steps,
                                       "face_b64": self._render_face_b64(96)})
        return {"ok": True}

    def _cmd_reward_soul(self, _):
        self.creature.soul.reward(self.creature.emotions.to_vec(), s=0.12)
        self.creature.relational.on_reward()
        self._push("soul_updated", self._soul_state())
        return {"ok": True}

    def _cmd_punish_soul(self, _):
        self.creature.soul.punish(self.creature.emotions.to_vec(), s=0.08)
        self.creature.relational.on_punish()
        self._push("soul_updated", self._soul_state())
        return {"ok": True}

    def _cmd_extrapolate(self, cmd):
        if self._last_x is None:
            return {"error": "No training run yet"}
        nn    = self._last_nn or self.creature.nn_store.get(self._last_itype)
        if nn is None:
            return {"error": "No network"}
        steps = max(1, int(cmd.get("steps", 5)))
        x     = self._last_x.copy()
        chain = []
        for i in range(steps):
            out = nn.forward(x, noise=0.005)
            chain.append({
                "step":  i + 1,
                "text":  self._decode_output(out)[:60],
                "mse":   round(float(np.mean((out - x) ** 2)), 6)
            })
            x = out
        return {"chain": chain}

    def _cmd_set_config(self, cmd):
        mapping = {
            "hidden_size":   ("cfg_hidden_size",   int),
            "learning_rate": ("cfg_learning_rate", float),
            "text_len":      ("cfg_text_len",       int),
            "img_dim":       ("cfg_img_dim",         int),
        }
        for key, (attr, cast) in mapping.items():
            if key in cmd:
                setattr(self, attr, cast(cmd[key]))
        return {"config": self._config_state()}

    def _cmd_set_name(self, cmd):
        if "brain_name" in cmd:
            self.creature.name = cmd["brain_name"]
        if "soul_name" in cmd:
            self.creature.soul.name = cmd["soul_name"]
        return {"ok": True}

    def _cmd_load_dict(self, cmd):
        path = cmd.get("path", "")
        if not os.path.exists(path):
            return {"error": f"File not found: {path}"}
        self.creature.word_dict = load_dictionary(path)
        return {"word_count": len(self.creature.word_dict)}

    # ── Care ──────────────────────────────────────────────────

    def _care(self, action: str):
        inst = self.creature.instincts
        em   = self.creature.emotions
        if action == "feed":
            inst.feed(); em.on_reward(); msg = "Fed"
        elif action == "sleep":
            inst.sleep()
            for nn in self.creature.nn_store.values():
                if nn: nn.consolidate(passes=3, lr=0.005)
            msg = "Resting — memory consolidated"
        elif action == "play":
            inst.play(); self._last_interact = datetime.datetime.now(); msg = "Play time"
        elif action == "soothe":
            inst.soothe()
            em.v["calm"] = min(1.0, em.v["calm"] + 0.12)
            em.v["fear"] = max(0.0, em.v["fear"] - 0.08)
            msg = "Soothed"
        else:
            msg = action
        self._push("care_applied", {"action": action, "msg": msg,
                                     "instincts": self._instinct_state(),
                                     "emotions":  self._emotion_state(),
                                     "face_b64":  self._render_face_b64(96)})

    def _approve_care(self):
        self.creature.soul.approve_care(
            self.creature.emotions.to_vec(), self.creature.relational)
        self.creature.emotions.on_reward()
        self._push("care_approved", {"soul": self._soul_state()})

    def _discourage_care(self):
        self.creature.soul.discourage_care(
            self.creature.emotions.to_vec(), self.creature.relational)
        self.creature.emotions.on_punish()
        self._push("care_discouraged", {"soul": self._soul_state()})

    # ── Ticks (background threads) ────────────────────────────

    def _schedule(self, delay: float, fn):
        def _run():
            import time
            while True:
                time.sleep(delay)
                try:
                    fn()
                except Exception:
                    pass
        t = threading.Thread(target=_run, daemon=True)
        t.start()

    def _emotion_tick(self):
        self.creature.instincts.tick()
        self.creature.instincts.influence_emotions(self.creature.emotions)
        self.creature.emotions.decay()
        self._push("tick_emotion", {
            "emotions":  self._emotion_state(),
            "instincts": self._instinct_state(),
            "relational":self._relational_state(),
        })

    def _soul_tick(self):
        ev      = self.creature.emotions.to_vec()
        self.creature.soul.forward(ev)
        thought = self.creature.soul.get_thought(self.creature.emotions)
        action, desc = self.creature.soul.decide_care(
            self.creature.instincts, self.creature.emotions, self.creature.relational)

        idle = (datetime.datetime.now() - self._last_interact).total_seconds()
        if (not self._running and not self._play_mode and idle > 90):
            self._enter_play()
        self._push("tick_soul", {
            "thought":    thought,
            "experience": round(self.creature.soul.experience, 3),
            "care_action": action,
            "care_desc":   desc,
            "soul":        self._soul_state(),
        })

    def _passive_train_tick(self):
        if (not self._running and self.creature.word_dict
                and self.creature.nn_store.get("text") is not None):
            nn   = self.creature.nn_store["text"]
            word = random.choice(self.creature.word_dict)
            x    = text_to_vec(word, self.cfg_text_len)
            nn.forward(x); nn.train(x, lr=self.cfg_learning_rate * 0.05)

    def _face_tick(self):
        self._push("tick_face", {"face_b64": self._render_face_b64(96)})

    # ── Play mode ─────────────────────────────────────────────

    def _enter_play(self):
        self._play_mode = True
        self._push("play_started", {"msg": "entering play mode"})
        threading.Thread(target=self._play_loop, daemon=True).start()

    def _exit_play(self):
        self._play_mode = False
        self._push("play_ended", {})

    def _play_loop(self):
        import time
        while self._play_mode:
            time.sleep(8)
            if not self._play_mode: break
            try:
                iv = self.creature.instincts.v
                if iv["tiredness"] > 0.80:
                    self.creature.instincts.sleep(); activity = "rest"
                else:
                    activities = ["generate_text", "memory_replay", "brain_explore"]
                    activity   = random.choice(activities)
                if activity == "generate_text":
                    self._spontaneous("play")
                elif activity == "memory_replay":
                    nn = self.creature.nn_store.get(self._last_itype)
                    if nn and nn._working_mem:
                        nn.consolidate(passes=1, lr=0.003)
                elif activity == "brain_explore":
                    nn = self.creature.nn_store.get(self._last_itype)
                    if nn and nn._working_mem:
                        x, _ = random.choice(nn._working_mem)
                        nn.forward(x); nn.train(x, lr=self.cfg_learning_rate * 0.02)
                self.creature.instincts.v["boredom"] = max(
                    0.0, iv["boredom"] - 0.06)
                self.creature.emotions.v["happiness"] = min(
                    1.0, self.creature.emotions.v["happiness"] + 0.04)
                self._push("play_tick", {
                    "activity": activity,
                    "face_b64": self._render_face_b64(96),
                    "emotions": self._emotion_state(),
                })
            except Exception:
                pass

    def _spontaneous(self, source="spontaneous"):
        nn = self.creature.nn_store.get("text")
        if nn is None: return
        ev       = self.creature.emotions.to_vec()
        soul_out = self.creature.soul.forward(ev).flatten()
        soul_mod = np.resize(soul_out, nn.input_size).reshape(1, -1)
        x        = np.random.rand(1, nn.input_size) * 0.7 + soul_mod * 0.3
        noise    = self.creature.emotions.noise_add() + 0.08
        out      = nn.forward(x, noise=noise)
        nn.train(x, lr=self._eff_lr() * 0.03)
        thought  = self.creature.soul.get_thought(self.creature.emotions)
        txt      = self._decode_output(out)[:60]
        self.creature.soul.add_memory(ev, "neutral")
        self.creature.soul.experience = min(2.0, self.creature.soul.experience + 0.005)
        self._push("spontaneous", {
            "source":  source,
            "thought": thought,
            "text":    txt,
            "face_b64": self._render_face_b64(96),
        })

    # ── Helpers ───────────────────────────────────────────────

    def _ensure_nn(self, itype, req_in, req_out) -> SimpleNN:
        nn = self.creature.nn_store.get(itype)
        if nn and nn.input_size == req_in and nn.output_size == req_out:
            return nn
        nn = SimpleNN(req_in, self.cfg_hidden_size, req_out, 0.1)
        self.creature.nn_store[itype] = nn
        return nn

    def _reset_networks(self):
        self.creature.nn_store = {"text": None, "image": None}
        self._push("networks_reset", self._config_state())

    def _eff_lr(self) -> float:
        lr = self.cfg_learning_rate
        lr *= self.creature.emotions.lr_mult() * self.creature.instincts.lr_mult()
        return max(1e-6, lr)

    def _decode_output(self, out) -> str:
        flat = out.flatten()
        if self.creature.word_dict:
            n    = len(self.creature.word_dict)
            idxs = [int(v * n) % n for v in flat[:6]]
            return " ".join(self.creature.word_dict[i] for i in idxs)
        return vec_to_text(flat, False)

    def _render_face_b64(self, size=96) -> str:
        nn  = self.creature.nn_store.get(self._last_itype)
        img = make_face(nn, self.creature.soul, self.creature.emotions,
                        self.creature.instincts, self.creature.relational, size=size)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode()

    def _hidden_heatmap(self, nn) -> list:
        grid = nn.hidden_grid()
        return grid.tolist()

    def _record_history(self, itype, mse, event):
        self._history.insert(0, {
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
            "itype": itype, "mse": round(mse, 6), "event": event
        })
        self._history = self._history[:20]

    # ── State serialisers ─────────────────────────────────────

    def _emotion_state(self) -> dict:
        return dict(self.creature.emotions.v)

    def _instinct_state(self) -> dict:
        iv = dict(self.creature.instincts.v)
        iv["wellbeing"] = round(self.creature.instincts.wellbeing(), 3)
        return iv

    def _soul_state(self) -> dict:
        s = self.creature.soul
        return {
            "experience":  round(s.experience, 3),
            "play_style":  round(s.play_style, 3),
            "name":        s.name,
        }

    def _relational_state(self) -> dict:
        r = self.creature.relational
        return {
            "attachment":  round(r.attachment, 3),
            "resentment":  round(r.resentment, 3),
            "description": r.description(),
        }

    def _config_state(self) -> dict:
        return {
            "hidden_size":   self.cfg_hidden_size,
            "learning_rate": self.cfg_learning_rate,
            "text_len":      self.cfg_text_len,
            "img_dim":       self.cfg_img_dim,
            "brain_name":    self.creature.name,
            "soul_name":     self.creature.soul.name,
        }

    def _full_state(self) -> dict:
        return {
            "config":    self._config_state(),
            "emotions":  self._emotion_state(),
            "instincts": self._instinct_state(),
            "soul":      self._soul_state(),
            "relational":self._relational_state(),
            "history":   self._history[:5],
            "face_b64":  self._render_face_b64(96),
            "word_count":len(self.creature.word_dict),
            "running":   self._running,
            "play_mode": self._play_mode,
            "rp_steps":  self._rp_steps,
        }
