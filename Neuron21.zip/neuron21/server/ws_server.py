"""
Neuron 21 — server/ws_server.py
Serves the frontend HTML/CSS/JS over HTTP and provides a WebSocket endpoint.
Uses only Python stdlib (http.server + websockets library).

Start with: python main.py
"""

import os
import sys
import json
import base64
import struct
import hashlib
import threading
import mimetypes
import socket
from http.server import HTTPServer, BaseHTTPRequestHandler

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server.engine import BrainEngine

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "frontend")

# Shared engine (one instance per process)
_engine: BrainEngine = None


# ── WebSocket protocol (RFC 6455) ─────────────────────────────

def _ws_handshake(conn, headers: dict) -> bool:
    key = headers.get("Sec-WebSocket-Key", "").strip()
    if not key:
        return False
    magic  = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    accept = base64.b64encode(
        hashlib.sha1((key + magic).encode()).digest()).decode()
    response = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
    )
    conn.sendall(response.encode())
    return True


def _ws_decode(data: bytes):
    """Decode a single WebSocket frame. Returns (text, remaining_bytes)."""
    if len(data) < 2:
        return None, data
    b0, b1   = data[0], data[1]
    masked   = bool(b1 & 0x80)
    plen     = b1 & 0x7F
    offset   = 2
    if plen == 126:
        if len(data) < 4: return None, data
        plen   = struct.unpack(">H", data[2:4])[0]; offset = 4
    elif plen == 127:
        if len(data) < 10: return None, data
        plen   = struct.unpack(">Q", data[2:10])[0]; offset = 10
    end = offset + (4 if masked else 0) + plen
    if len(data) < end:
        return None, data
    if masked:
        mask    = data[offset:offset+4]
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(data[offset+4:end]))
    else:
        payload = data[offset:end]
    opcode = b0 & 0x0F
    if opcode == 8:   # close
        return "__CLOSE__", data[end:]
    if opcode == 1:   # text
        return payload.decode("utf-8", errors="replace"), data[end:]
    return None, data[end:]


def _ws_encode(text: str) -> bytes:
    """Encode a text frame."""
    payload = text.encode("utf-8")
    n       = len(payload)
    if n < 126:
        hdr = bytes([0x81, n])
    elif n < 65536:
        hdr = struct.pack(">BBH", 0x81, 126, n)
    else:
        hdr = struct.pack(">BBQ", 0x81, 127, n)
    return hdr + payload


def _handle_ws_client(conn, addr):
    """Handle one WebSocket client connection."""
    send_lock = threading.Lock()

    def send(msg: str):
        try:
            with send_lock:
                conn.sendall(_ws_encode(msg))
        except Exception:
            pass

    _engine.subscribe(send)

    # Send initial full state
    state = _engine._full_state()
    send(json.dumps({"event": "init", "data": state}))

    buf = b""
    try:
        conn.settimeout(None)
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            buf += chunk
            while buf:
                text, buf = _ws_decode(buf)
                if text is None:
                    break
                if text == "__CLOSE__":
                    return
                try:
                    cmd    = json.loads(text)
                    result = _engine.handle_command(cmd)
                    send(json.dumps({"event": "reply",
                                     "id":    cmd.get("id"),
                                     "data":  result}))
                except json.JSONDecodeError as e:
                    send(json.dumps({"event": "error", "data": {"msg": str(e)}}))
    except Exception:
        pass
    finally:
        _engine.unsubscribe(send)
        try: conn.close()
        except Exception: pass


# ── HTTP + WebSocket handler ──────────────────────────────────

class N21Handler(BaseHTTPRequestHandler):
    """Handles both HTTP file serving and WebSocket upgrade."""

    def log_message(self, fmt, *args):
        pass  # suppress per-request stdout noise

    def do_GET(self):
        # WebSocket upgrade
        headers = {k: v for k, v in self.headers.items()}
        if (headers.get("Upgrade", "").lower() == "websocket"
                and headers.get("Connection", "").lower().find("upgrade") >= 0):
            if not _ws_handshake(self.connection, headers):
                self.send_error(400); return
            _handle_ws_client(self.connection, self.client_address)
            return

        # Serve static files
        path = self.path.split("?")[0]
        if path == "/" or path == "":
            path = "/index.html"
        local = os.path.normpath(os.path.join(FRONTEND_DIR, path.lstrip("/")))
        # Security: stay inside frontend dir
        if not local.startswith(FRONTEND_DIR):
            self.send_error(403); return
        if not os.path.isfile(local):
            self.send_error(404); return
        ctype, _ = mimetypes.guess_type(local)
        ctype    = ctype or "application/octet-stream"
        with open(local, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        """JSON command endpoint (fallback for non-WS clients)."""
        length = int(self.headers.get("Content-Length", 0))
        body   = self.rfile.read(length)
        try:
            cmd    = json.loads(body)
            result = _engine.handle_command(cmd)
            resp   = json.dumps(result).encode()
        except Exception as e:
            resp = json.dumps({"error": str(e)}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(resp)))
        self.end_headers()
        self.wfile.write(resp)


class N21Server:
    def __init__(self, host="127.0.0.1", port=7730):
        global _engine
        _engine  = BrainEngine()
        self.host = host
        self.port = port
        self._server = None

    def start(self, open_browser=True):
        # Allow port reuse
        HTTPServer.allow_reuse_address = True
        self._server = HTTPServer((self.host, self.port), N21Handler)
        url = f"http://{self.host}:{self.port}"
        print(f"Neuron 21  —  {url}")
        print("Press Ctrl-C to stop.")
        if open_browser:
            import webbrowser, time
            threading.Thread(
                target=lambda: (time.sleep(0.6), webbrowser.open(url)),
                daemon=True).start()
        try:
            self._server.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down.")
        finally:
            self._server.shutdown()
