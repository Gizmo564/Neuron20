"""
Neuron 21 — main.py
Entry point.  Run: python main.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from server.ws_server import N21Server


def main():
    server = N21Server(host="127.0.0.1", port=7730)
    server.start(open_browser=True)


if __name__ == "__main__":
    main()
