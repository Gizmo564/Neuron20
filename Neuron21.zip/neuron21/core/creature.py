"""
Neuron 20 — core/creature.py
Creature: unified container for all networks and state.
Handles save, load, and breeding.
"""

import os
import random
import datetime
import numpy as np

from core.networks import SimpleNN, SoulNN
from core.state    import EmotionState, InstinctSystem, RelationalState, GeneticsProfile


class Creature:
    """All data belonging to one living neural entity."""

    def __init__(self):
        self.name       = "New Creature"
        self.nn_store   = {"text": None, "image": None}
        self.soul       = SoulNN()
        self.emotions   = EmotionState()
        self.instincts  = InstinctSystem()
        self.relational = RelationalState()
        self.genetics   = GeneticsProfile()
        self.word_dict: list = []
        self.tag_registry: dict = {}  # tag -> [image_paths]
        self.image_tags: dict  = {}   # path -> tag
        # Interaction history
        self.bond: float     = 0.3
        self.rivalry: float  = 0.0

    # ── Persistence ───────────────────────────────────────────

    def save(self, fp: str, mode: str = "creature"):
        """
        Save to .npz.  mode: 'brain' | 'soul' | 'creature'
        """
        out: dict = {}

        if mode in ("brain", "creature"):
            for itype, nn in self.nn_store.items():
                if nn is None:
                    continue
                prefix = "B" if itype == "text" else "BI"
                out[f"{prefix}_W1"]  = nn.W1;  out[f"{prefix}_b1"]  = nn.b1
                out[f"{prefix}_W2"]  = nn.W2;  out[f"{prefix}_b2"]  = nn.b2
                out[f"{prefix}_in"]  = np.array(nn.input_size)
                out[f"{prefix}_hid"] = np.array(nn.hidden_size)
                out[f"{prefix}_out"] = np.array(nn.output_size)
                out[f"{prefix}_name"] = np.array(nn.name)

        if mode in ("soul", "creature"):
            s = self.soul
            out.update(S_W1=s.W1, S_b1=s.b1, S_W2=s.W2, S_b2=s.b2,
                       S_experience=np.array(s.experience),
                       S_name=np.array(s.name))
            if s._memory:
                out["soul_mem_vecs"]   = np.array([m[0] for m in s._memory])
                out["soul_mem_labels"] = np.array([m[1] for m in s._memory])

        if mode == "creature":
            out["creature_marker"]  = np.array(True)
            out["name"]             = np.array(self.name)
            out["genetics_emo"]     = self.genetics.to_array()
            out["relational_att"]   = np.array(self.relational.attachment)
            out["relational_res"]   = np.array(self.relational.resentment)
            out["interact_bond"]    = np.array(self.bond)
            out["interact_riv"]     = np.array(self.rivalry)
            out["saved_at"]         = np.array(
                datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

        np.savez(fp, **out)

    @classmethod
    def load(cls, fp: str) -> "Creature":
        d = np.load(fp, allow_pickle=True)
        c = cls()

        def _nn(prefix):
            k = f"{prefix}_W1"
            if k not in d:
                return None
            in_s  = int(d.get(f"{prefix}_in",  np.array(32)))
            hid_s = int(d.get(f"{prefix}_hid", np.array(64)))
            out_s = int(d.get(f"{prefix}_out", np.array(32)))
            nn = SimpleNN(in_s, hid_s, out_s)
            nn.W1 = d[f"{prefix}_W1"]; nn.b1 = d[f"{prefix}_b1"]
            nn.W2 = d[f"{prefix}_W2"]; nn.b2 = d[f"{prefix}_b2"]
            nn._init_momentum()
            nn.name = str(d.get(f"{prefix}_name", np.array("")))
            return nn

        c.nn_store["text"]  = _nn("B")  or _nn("text")
        c.nn_store["image"] = _nn("BI") or _nn("image")

        if "S_W1" in d:
            c.soul.W1 = d["S_W1"]; c.soul.b1 = d["S_b1"]
            c.soul.W2 = d["S_W2"]; c.soul.b2 = d["S_b2"]
            c.soul.experience = float(d.get("S_experience", np.array(0.0)))
            c.soul.name       = str(d.get("S_name", np.array("Soul")))
        if "soul_mem_vecs" in d:
            vecs   = d["soul_mem_vecs"]
            labels = d.get("soul_mem_labels", ["neutral"] * len(vecs))
            c.soul._memory = [(vecs[i], str(labels[i])) for i in range(len(vecs))]

        c.name = str(d.get("name", np.array(
            os.path.basename(fp).split(".")[0])))

        if "genetics_emo" in d:
            c.genetics = GeneticsProfile.from_array(d["genetics_emo"].flatten())
        if "relational_att" in d:
            c.relational.attachment = float(d["relational_att"])
            c.relational.resentment = float(d["relational_res"])
        c.bond    = float(d.get("interact_bond", np.array(0.3)))
        c.rivalry = float(d.get("interact_riv",  np.array(0.0)))
        return c

    # ── Breeding ──────────────────────────────────────────────

    @classmethod
    def breed(cls, parent_a: "Creature", parent_b: "Creature",
              mutation_rate: float = 0.10) -> "Creature":
        """
        Blend two creatures into a new offspring.
        """
        child = cls()
        child.name = f"Offspring of {parent_a.name} x {parent_b.name}"

        def blend(a, b, mut=mutation_rate):
            alpha = random.uniform(0.4, 0.6)
            v = alpha * a + (1 - alpha) * b
            if random.random() < mut:
                rng = max(abs(float(np.max(a))), abs(float(np.max(b)))) * 0.3 + 0.05
                v  += np.random.normal(0, rng, np.array(v).shape)
            return v

        # Blend text networks (must be same shape)
        nn_a = parent_a.nn_store["text"]
        nn_b = parent_b.nn_store["text"]
        if nn_a and nn_b and nn_a.W1.shape == nn_b.W1.shape:
            nn = SimpleNN(nn_a.input_size, nn_a.hidden_size, nn_a.output_size)
            nn.W1 = blend(nn_a.W1, nn_b.W1)
            nn.b1 = blend(nn_a.b1, nn_b.b1)
            nn.W2 = blend(nn_a.W2, nn_b.W2)
            nn.b2 = blend(nn_a.b2, nn_b.b2)
            nn._init_momentum()
            child.nn_store["text"] = nn
        elif nn_a:
            child.nn_store["text"] = nn_a

        # Soul blend
        sa, sb = parent_a.soul, parent_b.soul
        child.soul.W1 = blend(sa.W1, sb.W1)
        child.soul.b1 = blend(sa.b1, sb.b1)
        child.soul.W2 = blend(sa.W2, sb.W2)
        child.soul.b2 = blend(sa.b2, sb.b2)
        child.soul.experience = (sa.experience + sb.experience) / 2
        child.soul.play_style = blend(
            np.array([sa.play_style]), np.array([sb.play_style]))[0]

        # Soul memory seeds (top 20 from each parent)
        mem_a = sa._memory[:20]
        mem_b = sb._memory[:20]
        child.soul._memory = mem_a + mem_b

        # Genetics blend
        ga, gb = parent_a.genetics.to_array(), parent_b.genetics.to_array()
        child.genetics = GeneticsProfile.from_array(blend(ga, gb))

        # Relational baseline — gentle blend
        child.relational.attachment = (
            parent_a.relational.attachment + parent_b.relational.attachment) / 2
        child.relational.resentment = min(
            parent_a.relational.resentment, parent_b.relational.resentment)

        # Metadata
        child._lineage_a = parent_a.name
        child._lineage_b = parent_b.name
        child._generation = max(
            getattr(parent_a, "_generation", 0),
            getattr(parent_b, "_generation", 0)) + 1

        return child
