"""
Neuron 20 — core/networks.py
Neural network implementations: SimpleNN (autoencoder) and SoulNN.
"""

import numpy as np
import random


MOMENTUM = 0.85


class SimpleNN:
    """
    Single-hidden-layer autoencoder.
    Architecture: in -> hidden (tanh) -> out (sigmoid)
    Supports momentum SGD and working-memory consolidation.
    """

    def __init__(self, in_sz: int, hid_sz: int, out_sz: int, w_init: float = 0.1):
        self.input_size  = in_sz
        self.hidden_size = hid_sz
        self.output_size = out_sz
        self.name        = "Unnamed"

        scale = w_init / np.sqrt(in_sz)
        self.W1 = np.random.randn(in_sz,  hid_sz) * scale
        self.b1 = np.zeros((1, hid_sz))
        self.W2 = np.random.randn(hid_sz, out_sz) * scale
        self.b2 = np.zeros((1, out_sz))

        self._init_momentum()
        self._working_mem: list = []   # [(x_copy, mse), ...]  ring-buffer, max 128

    # ── Forward pass ──────────────────────────────────────────
    def forward(self, x: np.ndarray, noise: float = 0.0) -> np.ndarray:
        if noise > 0:
            x = x + np.random.randn(*x.shape) * noise
        self._h = np.tanh(x @ self.W1 + self.b1)
        out = 1 / (1 + np.exp(-np.clip(self._h @ self.W2 + self.b2, -60, 60)))
        self._x = x
        return out

    # ── Training step (momentum SGD) ──────────────────────────
    def train(self, target: np.ndarray, lr: float = 0.01) -> float:
        out  = self.forward(self._x if hasattr(self, '_x') else target)
        err  = out - target
        mse  = float(np.mean(err ** 2))

        # Backprop
        d2   = err * out * (1 - out)
        dW2  = self._h.T @ d2
        db2  = d2.sum(axis=0, keepdims=True)
        d1   = (d2 @ self.W2.T) * (1 - self._h ** 2)
        dW1  = self._x.T @ d1
        db1  = d1.sum(axis=0, keepdims=True)

        # Momentum update
        self.vW2 = MOMENTUM * self.vW2 - lr * dW2
        self.vb2 = MOMENTUM * self.vb2 - lr * db2
        self.vW1 = MOMENTUM * self.vW1 - lr * dW1
        self.vb1 = MOMENTUM * self.vb1 - lr * db1

        self.W2 += self.vW2;  self.b2 += self.vb2
        self.W1 += self.vW1;  self.b1 += self.vb1

        # Working memory
        self._working_mem.append((self._x.copy(), mse))
        if len(self._working_mem) > 128:
            self._working_mem.pop(0)

        return mse

    # ── Reward / punish shortcuts ─────────────────────────────
    def reward(self, x, lr_mult=1.5):
        self.forward(x); self.train(x, lr=0.01 * lr_mult)

    def punish(self, x, lr_mult=1.0):
        self.forward(x)
        noise_x = x + np.random.randn(*x.shape) * 0.05
        self.train(noise_x, lr=0.005 * lr_mult)

    # ── Noise injection ───────────────────────────────────────
    def add_weight_noise(self, sigma: float = 0.005):
        self.W1 += np.random.randn(*self.W1.shape) * sigma
        self.W2 += np.random.randn(*self.W2.shape) * sigma

    # ── Hidden activation grid ────────────────────────────────
    def hidden_grid(self) -> np.ndarray:
        side = int(np.ceil(np.sqrt(self.hidden_size)))
        grid = np.zeros(side * side)
        if hasattr(self, '_h'):
            flat = self._h.flatten()
            grid[:len(flat)] = (flat + 1) / 2   # tanh [-1,1] -> [0,1]
        return grid.reshape(side, side)

    # ── Memory consolidation (sleep / rest) ───────────────────
    def consolidate(self, passes: int = 2, lr: float = 0.006) -> int:
        if not self._working_mem:
            return 0
        high = sorted(self._working_mem, key=lambda t: t[1], reverse=True)
        subset = high[:max(1, len(high) // 3)]
        for _ in range(passes):
            for x, _ in subset:
                self.forward(x); self.train(x, lr=lr)
        return len(subset)

    # ── Persistence ───────────────────────────────────────────
    def save(self, fp: str, name: str = ""):
        np.savez(fp,
                 W1=self.W1, b1=self.b1, W2=self.W2, b2=self.b2,
                 name=np.array(name or self.name),
                 input_size=np.array(self.input_size),
                 hidden_size=np.array(self.hidden_size),
                 output_size=np.array(self.output_size))

    @classmethod
    def load(cls, fp: str) -> "SimpleNN":
        d   = np.load(fp, allow_pickle=True)
        nn  = cls(int(d["input_size"]), int(d["hidden_size"]), int(d["output_size"]))
        nn.W1 = d["W1"]; nn.b1 = d["b1"]
        nn.W2 = d["W2"]; nn.b2 = d["b2"]
        nn.name = str(d.get("name", np.array("")))
        nn._init_momentum()
        return nn

    def _init_momentum(self):
        self.vW1 = np.zeros_like(self.W1)
        self.vb1 = np.zeros_like(self.b1)
        self.vW2 = np.zeros_like(self.W2)
        self.vb2 = np.zeros_like(self.b2)


class SoulNN:
    """
    Secondary network that encodes emotional/spiritual state.
    6 emotion inputs -> 20 hidden (tanh) -> 10 outputs (sigmoid).
    Drives spontaneous generation and personality.
    """

    CARE_ACTIONS = ["generate_text", "generate_image", "rest", "seek_food", "soothe"]

    def __init__(self, hidden: int = 20):
        self.W1 = np.random.randn(6,  hidden) * 0.3
        self.b1 = np.zeros((1, hidden))
        self.W2 = np.random.randn(hidden, 10) * 0.3
        self.b2 = np.zeros((1, 10))
        self.name       = "Soul"
        self.experience = 0.0
        self.play_style = 0.5    # 0=image/artist, 1=text/thinker
        self._memory: list = []  # [(ev, label), ...]

        self.care_weights = {a: 1.0 for a in self.CARE_ACTIONS}
        self.last_care    = None

    def forward(self, ev: np.ndarray) -> np.ndarray:
        ev = np.array(ev).reshape(1, -1)
        h  = np.tanh(ev @ self.W1 + self.b1)
        return 1 / (1 + np.exp(-np.clip(h @ self.W2 + self.b2, -60, 60)))

    def reward(self, ev: np.ndarray, s: float = 0.1):
        self._update(ev, s, positive=True)

    def punish(self, ev: np.ndarray, s: float = 0.05):
        self._update(ev, s, positive=False)

    def _update(self, ev, s, positive):
        ev    = np.array(ev).reshape(1, -1)
        h     = np.tanh(ev @ self.W1 + self.b1)
        out   = 1 / (1 + np.exp(-np.clip(h @ self.W2 + self.b2, -60, 60)))
        target = np.ones_like(out) * (0.9 if positive else 0.1)
        err   = out - target
        d2    = err * out * (1 - out)
        dW2   = h.T @ d2;  db2 = d2.sum(0, keepdims=True)
        d1    = (d2 @ self.W2.T) * (1 - h**2)
        dW1   = ev.T @ d1; db1 = d1.sum(0, keepdims=True)
        self.W2 -= s * dW2; self.b2 -= s * db2
        self.W1 -= s * dW1; self.b1 -= s * db1
        self.experience = min(2.0, self.experience + 0.01)

    def add_memory(self, ev: np.ndarray, label: str):
        self._memory.append((np.array(ev).flatten(), label))
        if len(self._memory) > 200:
            self._memory = self._memory[-200:]

    def get_thought(self, emotions) -> str:
        ev  = np.array(list(emotions.v.values()))
        out = self.forward(ev).flatten()
        dom = int(np.argmax(out))
        thoughts = [
            "processing...", "a memory surfaces", "patterns shift",
            "something familiar", "reaching outward", "stillness",
            "an impulse forms", "curiosity peaks", "uncertainty",
            "resonance detected"
        ]
        return thoughts[dom % len(thoughts)]

    def decide_care(self, instincts, emotions, relational) -> tuple:
        """Return (action, description) or (None, None)."""
        iv = instincts.v; ev = emotions.v
        if relational.resentment > 0.75:
            return None, None
        w   = self.care_weights
        candidates = []
        if iv["boredom"] > 0.45:
            act = "generate_text" if self.play_style > 0.5 else "generate_image"
            candidates.append((act, "creative impulse", w[act] * iv["boredom"]))
        if iv["tiredness"] > 0.55:
            candidates.append(("rest", "need to rest", w["rest"] * iv["tiredness"]))
        if iv["pain"] > 0.30:
            candidates.append(("soothe", "seeking comfort", w["soothe"] * iv["pain"]))
        if iv["hunger"] > 0.60:
            candidates.append(("seek_food", "hungry", w["seek_food"] * iv["hunger"]))
        if not candidates:
            return None, None
        candidates.sort(key=lambda t: t[2], reverse=True)
        action, desc, _ = candidates[0]
        self.last_care  = (action, desc)
        return action, desc

    def approve_care(self, ev, relational):
        self.reward(ev, s=0.12)
        relational.on_reward()
        act = self.last_care[0] if self.last_care else None
        if act:
            self.care_weights[act] = min(3.0, self.care_weights[act] * 1.3)
        if act == "generate_image": self.play_style = max(0, self.play_style - 0.06)
        if act == "generate_text":  self.play_style = min(1, self.play_style + 0.06)

    def discourage_care(self, ev, relational):
        self.punish(ev, s=0.08)
        relational.on_punish()
        act = self.last_care[0] if self.last_care else None
        if act:
            self.care_weights[act] = max(0.1, self.care_weights[act] * 0.7)

    def hunger_nudge_msg(self) -> str:
        msgs = ["needs feeding", "hungry — try feeding it",
                "energy low", "feed the brain"]
        return random.choice(msgs)

    def save(self, fp: str, name: str = ""):
        np.savez(fp,
                 W1=self.W1, b1=self.b1, W2=self.W2, b2=self.b2,
                 soul_marker=np.array(True),
                 name=np.array(name or self.name),
                 experience=np.array(self.experience))

    @classmethod
    def load(cls, fp: str) -> "SoulNN":
        d    = np.load(fp, allow_pickle=True)
        soul = cls()
        soul.W1 = d["W1"]; soul.b1 = d["b1"]
        soul.W2 = d["W2"]; soul.b2 = d["b2"]
        soul.name       = str(d.get("name", np.array("Soul")))
        soul.experience = float(d.get("experience", np.array(0.0)))
        return soul
