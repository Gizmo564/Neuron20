"""
Neuron 20 — core/face.py
Structured geometric face renderer.  Returns a PIL Image (RGB, 96x96).
"""

import math
import numpy as np
from PIL import Image, ImageDraw


# Emotion -> hue mapping (H in 0-360)
EMOTION_HUE = dict(happiness=55, sadness=220, anger=0,
                   fear=290, curiosity=190, calm=150)


def emotion_rgb(emotions) -> tuple:
    """Return (r,g,b) floats 0-1 blended from active emotions."""
    r, g, b = 0.0, 0.0, 0.0
    total   = 0.0
    for name, hue in EMOTION_HUE.items():
        v = emotions.v.get(name, 0.0)
        if v < 0.01:
            continue
        h = hue / 360.0
        # Simple hue->RGB (unit saturation/value)
        i  = int(h * 6)
        f  = h * 6 - i
        q  = 1 - f
        rr, gg, bb = [
            (1, f, 0), (q, 1, 0), (0, 1, f),
            (0, q, 1), (f, 0, 1), (1, 0, q)
        ][i % 6]
        r += rr * v; g += gg * v; b += bb * v
        total += v
    if total > 0:
        r /= total; g /= total; b /= total
    return r, g, b


def make_face(nn, soul, emotions, instincts, relational, size: int = 96) -> Image.Image:
    img  = Image.new("RGB", (size, size), (15, 15, 26))
    draw = ImageDraw.Draw(img)
    cx, cy = size // 2, size // 2
    arr    = np.array(img, dtype=np.float32)
    ev     = emotions.v
    iv     = instincts.v

    # 1 ── Radial gradient background ─────────────────────────
    re_, ge_, be_ = emotion_rgb(emotions)
    for y in range(size):
        for x in range(size):
            dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / (size * 0.7)
            t    = max(0.0, 1.0 - dist)
            arr[y, x, 0] = min(255, arr[y, x, 0] + re_ * 40 * t)
            arr[y, x, 1] = min(255, arr[y, x, 1] + ge_ * 40 * t)
            arr[y, x, 2] = min(255, arr[y, x, 2] + be_ * 40 * t)
    img = Image.fromarray(arr.astype(np.uint8))
    draw = ImageDraw.Draw(img)

    # 2 ── Calm ring ───────────────────────────────────────────
    calm_alpha = int(ev.get("calm", 0.5) * 120)
    r_ring = int(size * 0.46)
    draw.ellipse([cx - r_ring, cy - r_ring, cx + r_ring, cy + r_ring],
                 outline=(calm_alpha, calm_alpha + 30, calm_alpha + 60), width=2)

    # 3 ── Hidden neuron petals ────────────────────────────────
    if nn is not None and hasattr(nn, "_h") and nn._h is not None:
        acts  = (nn._h.flatten() + 1) / 2   # [-1,1] -> [0,1]
        n_vis = min(24, len(acts))
        for i in range(n_vis):
            angle  = 2 * math.pi * i / n_vis
            bright = int(acts[i] * 180)
            px = int(cx + math.cos(angle) * size * 0.32)
            py = int(cy + math.sin(angle) * size * 0.32)
            r  = max(2, int(acts[i] * 6))
            draw.ellipse([px - r, py - r, px + r, py + r],
                         fill=(bright // 4, bright // 2, bright))

    # 4 ── Core disc ───────────────────────────────────────────
    cur_r = max(6, int(ev.get("curiosity", 0.5) * size * 0.22))
    draw.ellipse([cx - cur_r, cy - cur_r, cx + cur_r, cy + cur_r],
                 fill=(40, 60, 120))

    # 5 ── Anger pulse lines ───────────────────────────────────
    anger = ev.get("anger", 0.0)
    if anger > 0.2:
        for i in range(4):
            angle = math.pi / 2 * i
            x2 = int(cx + math.cos(angle) * size * 0.45 * anger)
            y2 = int(cy + math.sin(angle) * size * 0.45 * anger)
            draw.line([cx, cy, x2, y2],
                      fill=(int(200 * anger), 0, 0),
                      width=max(1, int(anger * 3)))

    # 6 ── Fear vignette ───────────────────────────────────────
    fear = ev.get("fear", 0.0)
    if fear > 0.1:
        arr2 = np.array(img, dtype=np.float32)
        for y in range(size):
            for x in range(size):
                dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / (size * 0.5)
                v    = min(1.0, dist) * fear * 0.6
                arr2[y, x] *= (1 - v)
        img  = Image.fromarray(arr2.astype(np.uint8))
        draw = ImageDraw.Draw(img)

    # 7 ── Soul sparkles ───────────────────────────────────────
    if soul is not None:
        s_out = soul.forward(
            np.array(list(ev.values()))
        ).flatten()
        for i, val in enumerate(s_out):
            if val > 0.65:
                angle = 2 * math.pi * i / len(s_out)
                px = int(cx + math.cos(angle) * size * 0.38)
                py = int(cy + math.sin(angle) * size * 0.38)
                c  = int(val * 220)
                draw.polygon([
                    (px, py - 3), (px + 2, py), (px, py + 3), (px - 2, py)
                ], fill=(c, c // 2, c))

    # 8 ── Centre pupil ────────────────────────────────────────
    draw.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=(230, 230, 250))

    # 9 ── Instinct overlays ───────────────────────────────────
    if iv.get("hunger", 0) > 0.5:
        # Golden shimmer ring
        ring_r = size // 2 - 2
        alpha  = int(iv["hunger"] * 180)
        draw.ellipse([cx - ring_r, cy - ring_r, cx + ring_r, cy + ring_r],
                     outline=(alpha, alpha // 2, 0), width=2)
    if iv.get("tiredness", 0) > 0.5:
        # Dim the whole image
        arr3 = np.array(img, dtype=np.float32)
        arr3 *= (1.0 - iv["tiredness"] * 0.4)
        img  = Image.fromarray(arr3.astype(np.uint8))
        draw = ImageDraw.Draw(img)
    if iv.get("pain", 0) > 0.3:
        # Red ripple
        rr = int(size * 0.35 + iv["pain"] * size * 0.1)
        alpha = int(iv["pain"] * 160)
        draw.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                     outline=(alpha, 0, 0), width=1)

    return img
