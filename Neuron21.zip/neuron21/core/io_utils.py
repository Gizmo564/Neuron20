"""
Neuron 20 — core/io_utils.py
Vector encoding/decoding, image loading, file helpers.
"""

import os
import numpy as np
from PIL import Image


ALLOWED_CHARS = list("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ")
ALLOWED_CODES = np.array([ord(c) / 255.0 for c in ALLOWED_CHARS])


def text_to_vec(text: str, max_len: int = 32) -> np.ndarray:
    v  = [ord(c) / 255.0 for c in text[:max_len]]
    v += [0.0] * (max_len - len(v))
    return np.array(v).reshape(1, -1)


def vec_to_text(v: np.ndarray, alpha_only: bool = False) -> str:
    flat = v.flatten()
    if alpha_only:
        return "".join(
            ALLOWED_CHARS[int(np.argmin(np.abs(ALLOWED_CODES - x)))]
            for x in flat
        )
    return "".join(
        chr(int(x * 255)) if 32 <= int(x * 255) <= 126 else "?"
        for x in flat
    )


def image_to_vec(path: str, size: tuple = (16, 16)) -> np.ndarray:
    img = Image.open(path).convert("L").resize(size)
    return (np.array(img).flatten() / 255.0).reshape(1, -1)


def load_dictionary(path: str) -> list:
    """Parse a plain-text word list — one word per line or whitespace-separated."""
    with open(path, encoding="utf-8", errors="ignore") as f:
        raw = f.read()
    words = [w.lower().strip() for w in raw.split() if w.isalpha() and len(w) > 1]
    return list(dict.fromkeys(words))   # deduplicate, preserve order


def save_long_term_memory(creature, fp: str):
    """Consolidate working memory then persist everything to .ltm.npz."""
    out: dict = {}
    for itype, nn in creature.nn_store.items():
        if nn is None:
            continue
        nn.consolidate(passes=4, lr=0.004)
        out[f"{itype}_W1"]  = nn.W1;  out[f"{itype}_b1"]  = nn.b1
        out[f"{itype}_W2"]  = nn.W2;  out[f"{itype}_b2"]  = nn.b2
        out[f"{itype}_in"]  = np.array(nn.input_size)
        out[f"{itype}_hid"] = np.array(nn.hidden_size)
        out[f"{itype}_out"] = np.array(nn.output_size)
    if creature.soul._memory:
        out["soul_mem_vecs"]   = np.array([m[0] for m in creature.soul._memory])
        out["soul_mem_labels"] = np.array([m[1] for m in creature.soul._memory])
    if creature.word_dict:
        out["word_dict"] = np.array(creature.word_dict)
    out["relational_att"] = np.array(creature.relational.attachment)
    out["relational_res"] = np.array(creature.relational.resentment)
    import datetime
    out["saved_at"] = np.array(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    np.savez(fp, **out)


def load_long_term_memory(creature, fp: str):
    """Restore weights and memories from a .ltm.npz file."""
    from core.networks import SimpleNN
    d = np.load(fp, allow_pickle=True)
    for itype in ("text", "image"):
        if f"{itype}_W1" not in d:
            continue
        in_s  = int(d[f"{itype}_in"])
        hid_s = int(d[f"{itype}_hid"])
        out_s = int(d[f"{itype}_out"])
        nn    = SimpleNN(in_s, hid_s, out_s)
        nn.W1 = d[f"{itype}_W1"]; nn.b1 = d[f"{itype}_b1"]
        nn.W2 = d[f"{itype}_W2"]; nn.b2 = d[f"{itype}_b2"]
        nn._init_momentum()
        creature.nn_store[itype] = nn
    if "soul_mem_vecs" in d:
        vecs   = d["soul_mem_vecs"]
        labels = d.get("soul_mem_labels", ["neutral"] * len(vecs))
        creature.soul._memory = [(vecs[i], str(labels[i])) for i in range(len(vecs))]
    if "word_dict" in d:
        creature.word_dict = list(d["word_dict"])
    if "relational_att" in d:
        creature.relational.attachment = float(d["relational_att"])
        creature.relational.resentment = float(d["relational_res"])
    return str(d.get("saved_at", np.array("unknown")))
