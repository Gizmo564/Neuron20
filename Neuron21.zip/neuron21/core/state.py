"""
Neuron 20 — core/state.py
EmotionState, InstinctSystem, RelationalState, GeneticsProfile.
"""

import numpy as np
import random


class EmotionState:
    NAMES    = ["happiness", "sadness", "anger", "fear", "curiosity", "calm"]
    BASELINE = dict(happiness=0.5, sadness=0.1, anger=0.1,
                    fear=0.1, curiosity=0.6, calm=0.6)

    def __init__(self):
        self.v = dict(self.BASELINE)

    def to_vec(self) -> np.ndarray:
        return np.array([self.v[n] for n in self.NAMES])

    def decay(self, rate: float = 0.02):
        for n in self.NAMES:
            self.v[n] += (self.BASELINE[n] - self.v[n]) * rate
            self.v[n]  = max(0.0, min(1.0, self.v[n]))

    def on_mse(self, mse: float):
        if mse < 0.05:
            self.v["happiness"] = min(1.0, self.v["happiness"] + 0.04)
            self.v["calm"]      = min(1.0, self.v["calm"]      + 0.02)
        elif mse > 0.3:
            self.v["sadness"]   = min(1.0, self.v["sadness"]   + 0.03)
            self.v["fear"]      = min(1.0, self.v["fear"]      + 0.02)

    def on_reward(self):
        self.v["happiness"] = min(1.0, self.v["happiness"] + 0.08)
        self.v["sadness"]   = max(0.0, self.v["sadness"]   - 0.04)

    def on_punish(self):
        self.v["anger"]     = min(1.0, self.v["anger"]     + 0.06)
        self.v["happiness"] = max(0.0, self.v["happiness"] - 0.04)

    def lr_mult(self) -> float:
        return (1.0
                + self.v["curiosity"] * 0.3
                - self.v["calm"]      * 0.1
                + self.v["fear"]      * 0.15)

    def noise_add(self) -> float:
        return self.v["anger"] * 0.04 + self.v["fear"] * 0.03


class InstinctSystem:
    DRIVES = ["hunger", "tiredness", "boredom", "pain"]

    def __init__(self):
        self.v = dict(hunger=0.3, tiredness=0.2, boredom=0.2, pain=0.0)

    def tick(self):
        self.v["hunger"]    = min(1.0, self.v["hunger"]    + 0.004)
        self.v["tiredness"] = min(1.0, self.v["tiredness"] + 0.003)
        self.v["boredom"]   = min(1.0, self.v["boredom"]   + 0.005)
        self.v["pain"]      = max(0.0, self.v["pain"]      - 0.005)

    def on_train(self, mse: float):
        self.v["hunger"]    = min(1.0, self.v["hunger"]    + 0.01)
        self.v["tiredness"] = min(1.0, self.v["tiredness"] + 0.005)
        self.v["boredom"]   = max(0.0, self.v["boredom"]   - 0.02)
        if mse > 0.3:
            self.v["pain"]  = min(1.0, self.v["pain"]      + 0.02)

    def influence_emotions(self, em: EmotionState):
        if self.v["hunger"] > 0.7:
            em.v["anger"]   = min(1.0, em.v["anger"]   + 0.03)
        if self.v["tiredness"] > 0.7:
            em.v["sadness"] = min(1.0, em.v["sadness"] + 0.02)
        if self.v["boredom"] > 0.7:
            em.v["curiosity"] = min(1.0, em.v["curiosity"] + 0.04)
        if self.v["pain"] > 0.5:
            em.v["fear"]    = min(1.0, em.v["fear"]    + 0.04)

    def feed(self):
        self.v["hunger"]    = max(0.0, self.v["hunger"]    - 0.5)
        self.v["pain"]      = max(0.0, self.v["pain"]      - 0.05)

    def sleep(self):
        self.v["tiredness"] = max(0.0, self.v["tiredness"] - 0.6)
        self.v["boredom"]   = max(0.0, self.v["boredom"]   - 0.1)

    def play(self):
        self.v["boredom"]   = max(0.0, self.v["boredom"]   - 0.4)
        self.v["tiredness"] = min(1.0, self.v["tiredness"] + 0.05)

    def soothe(self):
        self.v["pain"]      = max(0.0, self.v["pain"]      - 0.4)
        self.v["tiredness"] = max(0.0, self.v["tiredness"] - 0.1)

    def lr_mult(self) -> float:
        mult  = 1.0
        mult += self.v["hunger"]    * 0.2
        mult -= self.v["tiredness"] * 0.3
        mult -= self.v["pain"]      * 0.2
        return max(0.3, mult)

    def noise_add(self) -> float:
        return self.v["tiredness"] * 0.03 + self.v["pain"] * 0.02

    def wellbeing(self) -> float:
        penalty = (self.v["hunger"] + self.v["tiredness"] +
                   self.v["boredom"] + self.v["pain"])
        return max(0.0, 1.0 - penalty / 4.0)


class RelationalState:
    def __init__(self):
        self.attachment  = 0.3
        self.resentment  = 0.0

    def on_reward(self):
        self.attachment = min(1.0, self.attachment + 0.03)
        self.resentment = max(0.0, self.resentment - 0.02)

    def on_punish(self):
        self.resentment = min(1.0, self.resentment + 0.04)
        self.attachment = max(0.0, self.attachment - 0.01)

    def description(self) -> str:
        if self.resentment > 0.6:   return "Resentful"
        if self.attachment > 0.8:   return "Bonded"
        if self.attachment > 0.5:   return "Attached"
        if self.attachment < 0.15:  return "Distant"
        return "Neutral"


class GeneticsProfile:
    """
    Heritable personality parameters.
    Blended during breeding; evolve slowly through experience.
    """
    EMOTION_NAMES = EmotionState.NAMES

    def __init__(self):
        self.emo_susceptibility = {n: 1.0 for n in self.EMOTION_NAMES}
        self.learning_rate_base = 0.01
        self.mutation_rate      = 0.05
        self.instinct_rates     = dict(hunger=0.004, tiredness=0.003,
                                       boredom=0.005, pain=0.005)

    def to_array(self) -> np.ndarray:
        vals = [self.emo_susceptibility[n] for n in self.EMOTION_NAMES]
        vals += [self.learning_rate_base, self.mutation_rate]
        return np.array(vals)

    @classmethod
    def from_array(cls, arr: np.ndarray) -> "GeneticsProfile":
        g = cls()
        for i, n in enumerate(cls.EMOTION_NAMES):
            g.emo_susceptibility[n] = float(arr[i]) if i < len(arr) else 1.0
        if len(arr) > 6: g.learning_rate_base = float(arr[6])
        if len(arr) > 7: g.mutation_rate       = float(arr[7])
        return g
